$(document).ready(function(){
    
});

function first_load(){
    $("#first-page").css({
        display: 'none'
    });
}