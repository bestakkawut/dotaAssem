<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">        
        <link href="css/resetCss.css" rel="stylesheet" >
        <link href="css/index.css" rel="stylesheet" >
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
